#include "__cf_cas_pid.h"
#ifndef RTW_HEADER_cas_pid_acc_h_
#define RTW_HEADER_cas_pid_acc_h_
#include <stddef.h>
#ifndef cas_pid_acc_COMMON_INCLUDES_
#define cas_pid_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "cas_pid_acc_types.h"
#include "multiword_types.h"
#include "rt_defines.h"
typedef struct { real_T f4korhqnmp ; real_T l21mdumrsk ; real_T h3oft50bsl ;
real_T eydrcvlcpw ; real_T eul3iegiif ; } ecubfxsqbc ; typedef struct { void
* padqnj2hxe ; int_T eeokx3ofmg ; int_T g0xbkaxb4o ; } ksqoiqii1k ; typedef
struct { real_T c5kz4okzkm ; real_T nkanwnawi5 [ 2 ] ; real_T jylhblsozn [ 3
] ; real_T cemso0emuw ; } n2nlsjgmgi ; typedef struct { real_T c5kz4okzkm ;
real_T nkanwnawi5 [ 2 ] ; real_T jylhblsozn [ 3 ] ; real_T cemso0emuw ; }
pdfpncgr32 ; typedef struct { boolean_T c5kz4okzkm ; boolean_T nkanwnawi5 [ 2
] ; boolean_T jylhblsozn [ 3 ] ; boolean_T cemso0emuw ; } ku0pdxfwj0 ;
typedef struct { real_T c5kz4okzkm ; real_T nkanwnawi5 [ 2 ] ; real_T
jylhblsozn [ 3 ] ; real_T cemso0emuw ; } htoeheqjoj ; typedef struct { real_T
cr1frylm3v ; real_T hbi2xpmtie ; } kcftic2ua0 ; typedef struct { ZCSigState
jd5novu5lk ; ZCSigState dluelznflp ; } hu5cioiqrw ; struct hrhs05hkc5_ {
real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4 ; real_T P_5 ;
real_T P_6 [ 2 ] ; real_T P_7 [ 2 ] ; real_T P_8 [ 4 ] ; real_T P_9 ; real_T
P_10 ; real_T P_11 ; real_T P_12 ; real_T P_13 ; real_T P_14 ; real_T P_15 ;
real_T P_16 ; } ; extern hrhs05hkc5 jwqcffahtc ;
#endif
