#include "__cf_cas_pid.h"
#include <math.h>
#include "cas_pid_acc.h"
#include "cas_pid_acc_private.h"
#include <stdio.h>
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
static void mdlOutputs ( SimStruct * S , int_T tid ) { real_T h10jvbw1oo ;
real_T ngh15bmfdh ; real_T eiohlgmp5x ; ecubfxsqbc * _rtB ; hrhs05hkc5 * _rtP
; n2nlsjgmgi * _rtX ; ksqoiqii1k * _rtDW ; _rtDW = ( ( ksqoiqii1k * )
ssGetRootDWork ( S ) ) ; _rtX = ( ( n2nlsjgmgi * ) ssGetContStates ( S ) ) ;
_rtP = ( ( hrhs05hkc5 * ) ssGetDefaultParam ( S ) ) ; _rtB = ( ( ecubfxsqbc *
) _ssGetBlockIO ( S ) ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtDW ->
eeokx3ofmg = ( ssGetTaskTime ( S , 1 ) >= _rtP -> P_0 ) ; if ( _rtDW ->
eeokx3ofmg == 1 ) { eiohlgmp5x = _rtP -> P_2 ; } else { eiohlgmp5x = _rtP ->
P_1 ; } eiohlgmp5x *= _rtP -> P_3 ; _rtB -> f4korhqnmp = _rtP -> P_4 *
eiohlgmp5x ; _rtB -> l21mdumrsk = eiohlgmp5x ; } h10jvbw1oo = ( ( n2nlsjgmgi
* ) ssGetContStates ( S ) ) -> c5kz4okzkm ; _rtB -> eul3iegiif = 0.0 ; _rtB
-> eul3iegiif += _rtP -> P_10 * _rtX -> jylhblsozn [ 2 ] ;
ssCallAccelRunBlock ( S , 0 , 8 , SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit
( S , 1 , 0 ) ) { _rtDW -> g0xbkaxb4o = ( ssGetTaskTime ( S , 1 ) >= _rtP ->
P_11 ) ; if ( _rtDW -> g0xbkaxb4o == 1 ) { eiohlgmp5x = _rtP -> P_13 ; } else
{ eiohlgmp5x = _rtP -> P_12 ; } eiohlgmp5x *= _rtP -> P_14 ; _rtB ->
h3oft50bsl = eiohlgmp5x ; } ngh15bmfdh = ( ( n2nlsjgmgi * ) ssGetContStates (
S ) ) -> cemso0emuw ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> eydrcvlcpw
= _rtP -> P_16 * eiohlgmp5x ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { ecubfxsqbc * _rtB ;
hrhs05hkc5 * _rtP ; _rtP = ( ( hrhs05hkc5 * ) ssGetDefaultParam ( S ) ) ;
_rtB = ( ( ecubfxsqbc * ) _ssGetBlockIO ( S ) ) ; UNUSED_PARAMETER ( tid ) ;
}
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { ecubfxsqbc * _rtB ; hrhs05hkc5
* _rtP ; n2nlsjgmgi * _rtX ; pdfpncgr32 * _rtXdot ; _rtXdot = ( ( pdfpncgr32
* ) ssGetdX ( S ) ) ; _rtX = ( ( n2nlsjgmgi * ) ssGetContStates ( S ) ) ;
_rtP = ( ( hrhs05hkc5 * ) ssGetDefaultParam ( S ) ) ; _rtB = ( ( ecubfxsqbc *
) _ssGetBlockIO ( S ) ) ; { ( ( pdfpncgr32 * ) ssGetdX ( S ) ) -> c5kz4okzkm
= _rtB -> f4korhqnmp ; } _rtXdot -> nkanwnawi5 [ 0 ] = 0.0 ; _rtXdot ->
nkanwnawi5 [ 1 ] = 0.0 ; _rtXdot -> nkanwnawi5 [ 0 ] += _rtP -> P_6 [ 0 ] *
_rtX -> nkanwnawi5 [ 0 ] ; _rtXdot -> nkanwnawi5 [ 0 ] += _rtP -> P_6 [ 1 ] *
_rtX -> nkanwnawi5 [ 1 ] ; _rtXdot -> nkanwnawi5 [ 1 ] += _rtX -> nkanwnawi5
[ 0 ] ; _rtXdot -> nkanwnawi5 [ 0 ] += _rtB -> l21mdumrsk ; _rtXdot ->
jylhblsozn [ 0 ] = 0.0 ; _rtXdot -> jylhblsozn [ 1 ] = 0.0 ; _rtXdot ->
jylhblsozn [ 2 ] = 0.0 ; _rtXdot -> jylhblsozn [ 1 ] += _rtP -> P_8 [ 0 ] *
_rtX -> jylhblsozn [ 0 ] ; _rtXdot -> jylhblsozn [ 1 ] += _rtP -> P_8 [ 1 ] *
_rtX -> jylhblsozn [ 1 ] ; _rtXdot -> jylhblsozn [ 1 ] += _rtP -> P_8 [ 2 ] *
_rtX -> jylhblsozn [ 2 ] ; _rtXdot -> jylhblsozn [ 2 ] += _rtP -> P_8 [ 3 ] *
_rtX -> jylhblsozn [ 1 ] ; _rtXdot -> jylhblsozn [ 0 ] += _rtP -> P_9 * _rtB
-> h3oft50bsl ; { ( ( pdfpncgr32 * ) ssGetdX ( S ) ) -> cemso0emuw = _rtB ->
eydrcvlcpw ; } }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { hrhs05hkc5 * _rtP ;
kcftic2ua0 * _rtZCSV ; _rtZCSV = ( ( kcftic2ua0 * ) ssGetSolverZcSignalVector
( S ) ) ; _rtP = ( ( hrhs05hkc5 * ) ssGetDefaultParam ( S ) ) ; _rtZCSV ->
cr1frylm3v = ssGetT ( S ) - _rtP -> P_0 ; _rtZCSV -> hbi2xpmtie = ssGetT ( S
) - _rtP -> P_11 ; } static void mdlInitializeSizes ( SimStruct * S ) {
ssSetChecksumVal ( S , 0 , 3853329695U ) ; ssSetChecksumVal ( S , 1 ,
3335017706U ) ; ssSetChecksumVal ( S , 2 , 2922009305U ) ; ssSetChecksumVal (
S , 3 , 3986693940U ) ; { mxArray * slVerStructMat = NULL ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.5" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
ksqoiqii1k ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( ecubfxsqbc ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
hrhs05hkc5 ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetDefaultParam ( S , (
real_T * ) & jwqcffahtc ) ; } static void mdlInitializeSampleTimes (
SimStruct * S ) { } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
