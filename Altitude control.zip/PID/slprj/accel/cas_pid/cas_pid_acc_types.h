#include "__cf_cas_pid.h"
#ifndef RTW_HEADER_cas_pid_acc_types_h_
#define RTW_HEADER_cas_pid_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
typedef struct hrhs05hkc5_ hrhs05hkc5 ;
#endif
